@echo off
setlocal
set "GRADLE_VERSION=8.13"
set "BASE=%USERPROFILE%\.gradle\mali-wrapper\gradle-%GRADLE_VERSION%"
if not exist "%BASE%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path $env:USERPROFILE '.gradle\mali-wrapper\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -Force $zip (Split-Path '%BASE%')"
  if errorlevel 1 exit /b 1
)
call "%BASE%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
