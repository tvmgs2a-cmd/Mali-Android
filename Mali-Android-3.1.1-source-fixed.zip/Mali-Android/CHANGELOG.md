# Changelog

## 3.0.0 — Android Native foundation
- Replaced browser-only storage with Room/SQLite local database.
- Added native Compose interface with Arabic RTL and light/dark themes.
- Added transactions CRUD, monthly budgets, reports, car expenses and fuel stats.
- Added JSON/CSV export and JSON restore (including prior PWA backup files).
- Disabled network access and automatic Android backup.
- Added unit tests and GitHub Actions APK workflow.


## 3.1.0
- Added optional biometric app lock using AndroidX Biometric.
- Confirmed Moroccan dirham formatting remains the app currency.
- Documented that account login and cloud sync require a separately configured backend.
