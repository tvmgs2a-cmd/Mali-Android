package ma.mali.app.domain

import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth

 data class BackupPayload(
    val transactions: List<TransactionEntity>,
    val budgets: List<BudgetEntity>
)

object BackupCodec {
    fun encode(transactions: List<TransactionEntity>, budgets: List<BudgetEntity>): String {
        val txArray = JSONArray()
        transactions.forEach { item ->
            txArray.put(JSONObject().apply {
                put("id", item.id)
                put("type", item.type)
                put("amountMinor", item.amountMinor)
                put("amount", item.amountMinor / 100.0)
                put("note", item.note)
                put("category", item.category)
                put("date", item.date)
                put("liters", item.liters ?: JSONObject.NULL)
                put("odo", item.odoKm ?: JSONObject.NULL)
                put("createdAt", item.createdAt)
            })
        }
        val budgetArray = JSONArray()
        budgets.forEach { item ->
            budgetArray.put(JSONObject().apply {
                put("monthKey", item.monthKey)
                put("amountMinor", item.amountMinor)
            })
        }
        return JSONObject().apply {
            put("app", "Mali")
            put("schemaVersion", 3)
            put("exportedAt", java.time.Instant.now().toString())
            put("transactions", txArray)
            put("budgets", budgetArray)
        }.toString(2)
    }

    /** Imports native v3 backups and the earlier Mali PWA v2 JSON format. */
    fun decode(raw: String): BackupPayload {
        val root = JSONObject(raw)
        val txArray = root.optJSONArray("transactions")
            ?: throw IllegalArgumentException("ما لقيتش لائحة العمليات فالنسخة الاحتياطية")
        val transactions = buildList {
            for (index in 0 until txArray.length()) {
                val json = txArray.optJSONObject(index) ?: continue
                val type = json.optString("type", TxTypes.EXPENSE)
                    .takeIf { it in TxTypes.all } ?: TxTypes.EXPENSE
                val amountMinor = if (json.has("amountMinor") && !json.isNull("amountMinor")) {
                    json.optLong("amountMinor")
                } else {
                    (json.optDouble("amount", 0.0) * 100.0).toLong()
                }
                if (amountMinor <= 0L) continue
                val date = json.optString("date", LocalDate.now().toString())
                try { LocalDate.parse(date) } catch (_: Exception) { continue }
                val liters = if (!json.isNull("liters") && json.has("liters")) json.optDouble("liters").takeIf { it > 0.0 } else null
                val odo = if (!json.isNull("odo") && json.has("odo")) json.optDouble("odo").toLong().takeIf { it > 0L }
                    else if (!json.isNull("odoKm") && json.has("odoKm")) json.optLong("odoKm").takeIf { it > 0L }
                    else null
                add(
                    TransactionEntity(
                        id = json.optLong("id", 0L).takeIf { it > 0L } ?: (System.currentTimeMillis() + index),
                        type = type,
                        amountMinor = amountMinor,
                        note = json.optString("note", TxTypes.label(type)).take(160),
                        category = json.optString("category", "أخرى").take(80),
                        date = date,
                        liters = liters,
                        odoKm = odo,
                        createdAt = json.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }
        val budgetArray = root.optJSONArray("budgets")
        val budgets = if (budgetArray != null) {
            buildList {
                for (index in 0 until budgetArray.length()) {
                    val json = budgetArray.optJSONObject(index) ?: continue
                    val month = json.optString("monthKey")
                    val amount = json.optLong("amountMinor", 0L)
                    if (month.matches(Regex("\\d{4}-\\d{2}")) && amount >= 0L) {
                        add(BudgetEntity(monthKey = month, amountMinor = amount))
                    }
                }
            }
        } else {
            // Previous PWA used one shared monthly budget value.
            val oldBudget = root.optDouble("budget", -1.0)
            if (oldBudget >= 0.0) listOf(
                BudgetEntity(YearMonth.now().toString(), (oldBudget * 100.0).toLong())
            ) else emptyList()
        }
        return BackupPayload(transactions, budgets)
    }
}
