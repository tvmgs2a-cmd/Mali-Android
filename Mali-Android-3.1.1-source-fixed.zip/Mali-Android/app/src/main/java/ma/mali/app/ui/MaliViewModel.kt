package ma.mali.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.MaliDatabase
import ma.mali.app.data.MaliRepository
import ma.mali.app.data.TransactionEntity
import ma.mali.app.domain.BackupPayload
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MaliViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MaliRepository(MaliDatabase.getInstance(application))

    val transactions = repository.transactions.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )
    val budgets = repository.budgets.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )

    fun saveTransaction(item: TransactionEntity, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveTransaction(item)
            onDone?.invoke()
        }
    }

    fun deleteTransaction(id: Long, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
            onDone?.invoke()
        }
    }

    fun saveBudget(monthKey: String, amountMinor: Long, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveBudget(BudgetEntity(monthKey, amountMinor))
            onDone?.invoke()
        }
    }

    fun replaceBackup(payload: BackupPayload, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.replaceAll(payload.transactions, payload.budgets)
            onDone?.invoke()
        }
    }
}
