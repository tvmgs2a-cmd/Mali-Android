package ma.mali.app.domain

import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object Finance {
    data class Totals(val incomeMinor: Long, val expenseMinor: Long) {
        val balanceMinor: Long get() = incomeMinor - expenseMinor
        val netMinor: Long get() = incomeMinor - expenseMinor
    }

    data class FuelStats(
        val distanceKm: Long = 0,
        val usedLiters: Double = 0.0,
        val totalCostMinor: Long = 0,
        val litersPer100Km: Double? = null,
        val costPerKm: Double? = null
    )

    fun totals(items: List<TransactionEntity>): Totals = Totals(
        incomeMinor = items.filter { it.type == TxTypes.INCOME }.sumOf { it.amountMinor },
        expenseMinor = items.filter { TxTypes.isExpense(it.type) }.sumOf { it.amountMinor }
    )

    fun month(items: List<TransactionEntity>, monthKey: String): List<TransactionEntity> =
        items.filter { it.date.startsWith(monthKey) }

    fun fuelStats(items: List<TransactionEntity>): FuelStats {
        val fills = items.asSequence()
            .filter { it.type == TxTypes.FUEL && (it.liters ?: 0.0) > 0.0 && (it.odoKm ?: 0L) > 0L }
            .sortedBy { it.odoKm }
            .toList()
        if (fills.size < 2) return FuelStats()

        var distance = 0L
        var liters = 0.0
        var cost = 0L
        for (index in 1 until fills.size) {
            val previous = fills[index - 1].odoKm ?: continue
            val current = fills[index]
            val delta = (current.odoKm ?: continue) - previous
            if (delta > 0L) {
                distance += delta
                liters += current.liters ?: 0.0
                cost += current.amountMinor
            }
        }
        if (distance <= 0L || liters <= 0.0) return FuelStats()
        return FuelStats(
            distanceKm = distance,
            usedLiters = liters,
            totalCostMinor = cost,
            litersPer100Km = liters / distance.toDouble() * 100.0,
            costPerKm = (cost / 100.0) / distance.toDouble()
        )
    }

    fun amountToMinor(raw: String): Long? {
        return try {
            val normalized = raw.trim().replace(',', '.')
            if (normalized.isEmpty()) null else BigDecimal(normalized)
                .movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
                .takeIf { it > 0L }
        } catch (_: Exception) {
            null
        }
    }

    fun formatMoney(minor: Long): String {
        val symbols = DecimalFormatSymbols(Locale.US)
        val formatter = DecimalFormat("#,##0.00", symbols)
        return "${formatter.format(minor / 100.0)} د.م"
    }

    fun formatNumber(value: Double, decimals: Int = 2): String {
        val pattern = if (decimals <= 0) "#,##0" else "#,##0." + "0".repeat(decimals)
        return DecimalFormat(pattern, DecimalFormatSymbols(Locale.US)).format(value)
    }
}
