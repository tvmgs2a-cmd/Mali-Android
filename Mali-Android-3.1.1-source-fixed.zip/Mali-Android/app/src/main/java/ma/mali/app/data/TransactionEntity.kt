package ma.mali.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    /** Amount in centimes to avoid floating-point currency errors. */
    val amountMinor: Long,
    val note: String,
    val category: String,
    /** ISO-8601 local date: yyyy-MM-dd. */
    val date: String,
    val liters: Double? = null,
    val odoKm: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

object TxTypes {
    const val INCOME = "income"
    const val EXPENSE = "expense"
    const val FUEL = "fuel"
    const val MAINTENANCE = "maintenance"
    const val INSURANCE = "insurance"
    const val CAR_OTHER = "carother"

    val all = setOf(INCOME, EXPENSE, FUEL, MAINTENANCE, INSURANCE, CAR_OTHER)
    val car = setOf(FUEL, MAINTENANCE, INSURANCE, CAR_OTHER)

    fun label(type: String): String = when (type) {
        INCOME -> "مدخول"
        EXPENSE -> "مصروف"
        FUEL -> "الوقود"
        MAINTENANCE -> "الصيانة"
        INSURANCE -> "التأمين والوثائق"
        CAR_OTHER -> "مصاريف أخرى للسيارة"
        else -> "مصروف"
    }

    fun isExpense(type: String): Boolean = type != INCOME
    fun isCar(type: String): Boolean = type in car
}
