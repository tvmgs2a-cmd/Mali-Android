package ma.mali.app.ui

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ma.mali.app.data.BudgetEntity
import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import ma.mali.app.domain.BackupCodec
import ma.mali.app.domain.BackupPayload
import ma.mali.app.domain.Finance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.Executor

private enum class MainTab { HOME, HISTORY, CARS, REPORTS }

class MainActivity : FragmentActivity() {
    private var isUnlocked by mutableStateOf(true)
    private var biometricEnabled by mutableStateOf(false)
    private var pendingBiometricSuccess: (() -> Unit)? = null
    private lateinit var biometricPrompt: BiometricPrompt
    private val prefs by lazy { getSharedPreferences("mali_preferences", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        biometricEnabled = prefs.getBoolean("biometric_enabled", false)
        isUnlocked = !biometricEnabled
        biometricPrompt = BiometricPrompt(
            this,
            Executor { command -> runOnUiThread(command) },
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    pendingBiometricSuccess?.invoke()
                    pendingBiometricSuccess = null
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    pendingBiometricSuccess = null
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED) {
                        Toast.makeText(this@MainActivity, "تعذر التحقق بالبصمة: $errString", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
        setContent {
            MaliApp(
                isUnlocked = isUnlocked,
                biometricEnabled = biometricEnabled,
                onUnlock = { authenticateBiometric { isUnlocked = true } },
                onEnableBiometric = {
                    authenticateBiometric {
                        prefs.edit().putBoolean("biometric_enabled", true).apply()
                        biometricEnabled = true
                        isUnlocked = true
                        Toast.makeText(this, "تفعّلات الحماية بالبصمة", Toast.LENGTH_SHORT).show()
                    }
                },
                onDisableBiometric = {
                    authenticateBiometric {
                        prefs.edit().putBoolean("biometric_enabled", false).apply()
                        biometricEnabled = false
                        isUnlocked = true
                        Toast.makeText(this, "توقّف قفل التطبيق", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    private fun authenticateBiometric(onSuccess: () -> Unit) {
        val allowedAuthenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val availability = BiometricManager.from(this).canAuthenticate(allowedAuthenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            val message = when (availability) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "هاد الهاتف ما فيهش مستشعر بصمة متوافق."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "مستشعر البصمة ما متاحش دابا."
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "سجّل بصمة أو رمز قفل للهاتف من الإعدادات."
                else -> "البصمة ما متاحةش على هاد الجهاز."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            return
        }
        pendingBiometricSuccess = onSuccess
        val prompt = BiometricPrompt.PromptInfo.Builder()
            .setTitle("حماية Mali")
            .setSubtitle("أكد هويتك بالبصمة أو برمز قفل الهاتف")
            .setAllowedAuthenticators(allowedAuthenticators)
            .build()
        biometricPrompt.authenticate(prompt)
    }
}

@Composable
private fun MaliApp(
    isUnlocked: Boolean,
    biometricEnabled: Boolean,
    onUnlock: () -> Unit,
    onEnableBiometric: () -> Unit,
    onDisableBiometric: () -> Unit,
    vm: MaliViewModel = viewModel()
) {
    if (!isUnlocked) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF6259DF))) {
            LockedScreen(onUnlock = onUnlock)
        }
        return
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val transactions by vm.transactions.collectAsStateWithLifecycle()
    val budgets by vm.budgets.collectAsStateWithLifecycle()
    val prefs = remember { context.getSharedPreferences("mali_preferences", Context.MODE_PRIVATE) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var editorItem by remember { mutableStateOf<TransactionEntity?>(null) }
    var editorType by rememberSaveable { mutableStateOf(TxTypes.EXPENSE) }
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var deleteItem by remember { mutableStateOf<TransactionEntity?>(null) }
    var pendingBackup by remember { mutableStateOf<BackupPayload?>(null) }
    var showSecurityDialog by remember { mutableStateOf(false) }

    val jsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(BackupCodec.encode(transactions, budgets))
                } ?: error("تعذر فتح ملف النسخة الاحتياطية")
            }.onSuccess { launchToast(context, "تصدّرات النسخة الاحتياطية") }
                .onFailure { launchToast(context, "ما قدرناش نصاوبو النسخة: ${it.message}") }
        }
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            runCatching {
                val content = buildCsv(transactions)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                    ?: error("تعذر فتح ملف CSV")
            }.onSuccess { launchToast(context, "تصدّر ملف CSV") }
                .onFailure { launchToast(context, "فشل التصدير: ${it.message}") }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("ما قدرناش نقراو الملف")
                BackupCodec.decode(raw)
            }.onSuccess { payload ->
                launchMain(context) { pendingBackup = payload }
            }.onFailure { launchToast(context, "الملف ماشي نسخة Mali صالحة: ${it.message}") }
        }
    }

    MaterialTheme(colorScheme = if (darkMode) darkColorScheme(
        primary = Color(0xFFAAA2FF), secondary = Color(0xFF75D9B2), background = Color(0xFF101522),
        surface = Color(0xFF1B2435), onSurface = Color(0xFFEAF0FA), onBackground = Color(0xFFEAF0FA)
    ) else lightColorScheme(
        primary = Color(0xFF6259DF), secondary = Color(0xFF168B69), background = Color(0xFFF5F6FB),
        surface = Color.White, onSurface = Color(0xFF1B2435), onBackground = Color(0xFF1B2435)
    )) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val tabs = listOf(
                        Triple(MainTab.HOME, "⌂", "الرئيسية"),
                        Triple(MainTab.HISTORY, "▤", "السجل"),
                        Triple(MainTab.CARS, "🚗", "السيارة"),
                        Triple(MainTab.REPORTS, "▥", "التقارير")
                    )
                    tabs.forEach { (item, icon, label) ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(icon, style = MaterialTheme.typography.titleMedium) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                AppHeader(
                    darkMode = darkMode,
                    onToggleTheme = {
                        darkMode = !darkMode
                        prefs.edit().putBoolean("dark_mode", darkMode).apply()
                    },
                    onSecurity = { showSecurityDialog = true }
                )
                when (tab) {
                    MainTab.HOME -> HomeScreen(
                        transactions = transactions,
                        budgets = budgets,
                        onAdd = { type -> editorType = type; editorItem = null; showEditor = true },
                        onHistory = { tab = MainTab.HISTORY }
                    )
                    MainTab.HISTORY -> HistoryScreen(
                        transactions = transactions,
                        onEdit = { item -> editorItem = item; editorType = item.type; showEditor = true },
                        onDelete = { deleteItem = it }
                    )
                    MainTab.CARS -> CarsScreen(
                        transactions = transactions,
                        onEdit = { item -> editorItem = item; editorType = item.type; showEditor = true },
                        onDelete = { deleteItem = it }
                    )
                    MainTab.REPORTS -> ReportsScreen(
                        transactions = transactions,
                        budgets = budgets,
                        onSaveBudget = { month, amount -> vm.saveBudget(month, amount) },
                        onExportJson = { jsonLauncher.launch("mali-backup-${LocalDate.now()}.json") },
                        onExportCsv = { csvLauncher.launch("mali-operations-${LocalDate.now()}.csv") },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/json", "application/octet-stream")) }
                    )
                }
            }
        }
    }

    if (showEditor) {
        TransactionEditorDialog(
            initial = editorItem,
            initialType = editorType,
            onDismiss = { showEditor = false; editorItem = null },
            onSave = { item ->
                vm.saveTransaction(item) {
                    launchToast(context, "تحفظات العملية")
                }
                showEditor = false
                editorItem = null
            }
        )
    }

    deleteItem?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteItem = null },
            title = { Text("حذف العملية؟") },
            text = { Text("واش متأكد بغيتي تمسح «${item.note}» بمبلغ ${Finance.formatMoney(item.amountMinor)}؟") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteTransaction(item.id) { launchToast(context, "تم حذف العملية") }
                    deleteItem = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteItem = null }) { Text("إلغاء") } }
        )
    }

    if (showSecurityDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = { Text("حماية التطبيق") },
            text = {
                Text(
                    if (biometricEnabled) "قفل التطبيق مفعّل. غادي يطلب Mali البصمة أو رمز قفل الهاتف ملي تفتح التطبيق من جديد."
                    else "فعّل القفل باش ما يتفتحش Mali حتى تأكد هويتك بالبصمة أو برمز قفل الهاتف."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showSecurityDialog = false
                    if (biometricEnabled) onDisableBiometric() else onEnableBiometric()
                }) { Text(if (biometricEnabled) "إيقاف الحماية" else "تفعيل القفل") }
            },
            dismissButton = { TextButton(onClick = { showSecurityDialog = false }) { Text("إلغاء") } }
        )
    }

    pendingBackup?.let { backup ->
        AlertDialog(
            onDismissRequest = { pendingBackup = null },
            title = { Text("استرجاع النسخة الاحتياطية") },
            text = {
                Text("هاد العملية غادي تعوّض البيانات الحالية بـ ${backup.transactions.size} عملية و${backup.budgets.size} ميزانية. دير نسخة احتياطية من بياناتك الحالية قبل الاسترجاع إلا كنت محتاجها.")
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.replaceBackup(backup) { launchToast(context, "ترجعات البيانات بنجاح") }
                    pendingBackup = null
                }) { Text("تعويض البيانات") }
            },
            dismissButton = { TextButton(onClick = { pendingBackup = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun LockedScreen(onUnlock: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFFF5F6FB)).padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Mali", color = Color(0xFF6259DF), fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineLarge)
            Text("التطبيق محمي", color = Color(0xFF1B2435), style = MaterialTheme.typography.titleMedium)
            Text("أكد هويتك بالبصمة أو برمز قفل الهاتف باش توصل للبيانات المالية.", color = Color(0xFF525B6B), style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth()) { Text("فتح التطبيق") }
        }
    }
}

@Composable
private fun AppHeader(darkMode: Boolean, onToggleTheme: () -> Unit, onSecurity: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) { Text("م", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Mali", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text("تدبير فلوسك بذكاء", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onSecurity) { Text("🔐", style = MaterialTheme.typography.titleLarge) }
        IconButton(onClick = onToggleTheme) { Text(if (darkMode) "☀" else "☾", style = MaterialTheme.typography.titleLarge) }
    }
}

@Composable
private fun HomeScreen(
    transactions: List<TransactionEntity>,
    budgets: List<BudgetEntity>,
    onAdd: (String) -> Unit,
    onHistory: () -> Unit
) {
    val month = YearMonth.now().toString()
    val monthItems = Finance.month(transactions, month)
    val totals = Finance.totals(transactions)
    val monthTotals = Finance.totals(monthItems)
    val budget = budgets.firstOrNull { it.monthKey == month }?.amountMinor ?: 0L
    val ratio = if (budget > 0) monthTotals.expenseMinor.toDouble() / budget else 0.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("الرصيد الإجمالي", color = Color.White.copy(alpha = .84f), style = MaterialTheme.typography.bodyMedium)
                Text(Finance.formatMoney(totals.balanceMinor), color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BalanceMini("مجموع المداخيل", totals.incomeMinor, true, Modifier.weight(1f))
                    BalanceMini("مجموع المصاريف", totals.expenseMinor, false, Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ملخص هاد الشهر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(month, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryMini("المداخيل", monthTotals.incomeMinor, Color(0xFF168B69), Modifier.weight(1f))
                    SummaryMini("المصاريف", monthTotals.expenseMinor, MaterialTheme.colorScheme.error, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الميزانية", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(if (budget > 0) "${Finance.formatMoney(monthTotals.expenseMinor)} / ${Finance.formatMoney(budget)}" else "ما تحدداتش", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { ratio.coerceIn(0.0, 1.0).toFloat() },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = if (ratio > 1.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    when {
                        budget <= 0 -> "حدد الميزانية من صفحة التقارير."
                        ratio > 1.0 -> "تجاوزتي الميزانية بـ ${Finance.formatMoney(monthTotals.expenseMinor - budget)}."
                        else -> "باقي ليك ${Finance.formatMoney(budget - monthTotals.expenseMinor)} من الميزانية."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
        SectionTitle("إضافة سريعة")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickButton("＋", "مدخول", Modifier.weight(1f)) { onAdd(TxTypes.INCOME) }
            QuickButton("−", "مصروف", Modifier.weight(1f)) { onAdd(TxTypes.EXPENSE) }
            QuickButton("⛽", "وقود", Modifier.weight(1f)) { onAdd(TxTypes.FUEL) }
            QuickButton("🔧", "سيارة", Modifier.weight(1f)) { onAdd(TxTypes.MAINTENANCE) }
        }
        SectionTitle("آخر العمليات", "عرض الكل", onHistory)
        if (transactions.isEmpty()) EmptyState("مازال ما سجلتي حتى عملية. بدا بإضافة مدخول أو مصروف.")
        else transactions.take(5).forEach { TransactionRow(it, showActions = false, onEdit = {}, onDelete = {}) }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun BalanceMini(title: String, value: Long, positive: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .14f)).padding(11.dp)) {
        Text(title, color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.labelSmall)
        Text((if (positive) "+" else "−") + Finance.formatMoney(value), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun SummaryMini(title: String, value: Long, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f)).padding(11.dp)) {
        Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        Text(Finance.formatMoney(value), color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickButton(icon: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(5.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun HistoryScreen(
    transactions: List<TransactionEntity>,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("all") }
    var month by rememberSaveable { mutableStateOf("all") }
    val months = transactions.map { it.date.take(7) }.distinct().sortedDescending()
    val visible = transactions.filter { item ->
        val matchesType = when (filter) {
            "income" -> item.type == TxTypes.INCOME
            "expense" -> TxTypes.isExpense(item.type) && !TxTypes.isCar(item.type)
            "car" -> TxTypes.isCar(item.type)
            else -> true
        }
        val searchText = "${item.note} ${item.category} ${TxTypes.label(item.type)} ${item.date}".lowercase(Locale.ROOT)
        matchesType && (month == "all" || item.date.startsWith(month)) && (query.isBlank() || searchText.contains(query.trim().lowercase(Locale.ROOT)))
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, label = { Text("قلب على عملية أو تصنيف") },
            modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Text("⌕") }
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("all" to "الكل", "income" to "المداخيل", "expense" to "المصاريف", "car" to "السيارة").forEach { (key, label) ->
                FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(label) })
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(selected = month == "all", onClick = { month = "all" }, label = { Text("جميع الشهور") })
            months.forEach { key -> FilterChip(selected = month == key, onClick = { month = key }, label = { Text(key) }) }
        }
        Text("${visible.size} عملية", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 6.dp))
        if (visible.isEmpty()) EmptyState("ما لقيت حتى عملية مطابقة.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(visible, key = { it.id }) { item -> TransactionRow(item, true, { onEdit(item) }, { onDelete(item) }) }
        }
    }
}

@Composable
private fun CarsScreen(
    transactions: List<TransactionEntity>,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    val cars = transactions.filter { TxTypes.isCar(it.type) }
    val fuel = Finance.fuelStats(transactions)
    val amountByType = TxTypes.car.associateWith { type -> cars.filter { it.type == type }.sumOf { it.amountMinor } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("مصاريف السيارة", fontWeight = FontWeight.Bold)
                Text(Finance.formatMoney(cars.sumOf { it.amountMinor }), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryMini("الوقود", amountByType[TxTypes.FUEL] ?: 0L, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    SummaryMini("الصيانة", amountByType[TxTypes.MAINTENANCE] ?: 0L, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryMini("التأمين", amountByType[TxTypes.INSURANCE] ?: 0L, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
                    SummaryMini("أخرى", amountByType[TxTypes.CAR_OTHER] ?: 0L, MaterialTheme.colorScheme.error, Modifier.weight(1f))
                }
            }
        }
        SectionTitle("تحليل استهلاك الوقود")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FuelMetric("الاستهلاك", fuel.litersPer100Km?.let { "${Finance.formatNumber(it)} لتر/100كم" } ?: "—", Modifier.weight(1f))
                    FuelMetric("المسافة", if (fuel.distanceKm > 0) "${Finance.formatNumber(fuel.distanceKm.toDouble(), 0)} كم" else "—", Modifier.weight(1f))
                }
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FuelMetric("تكلفة الوقود", Finance.formatMoney(fuel.totalCostMinor), Modifier.weight(1f))
                    FuelMetric("ثمن الكيلومتر", fuel.costPerKm?.let { "${Finance.formatNumber(it)} د.م" } ?: "—", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    if (fuel.distanceKm <= 0) "سجّل جوج تعبئات على الأقل، وفي كل مرة دخل اللترات وقراءة العداد. الحساب تقديري وكيعتمد على التعبئة الكاملة للخزان."
                    else "الحساب تقديري بين ${Finance.formatNumber(fuel.distanceKm.toDouble(), 0)} كلم مسجلة. باش تكون النتيجة أدق، عمّر الخزان كامل كل مرة وسجّل قراءة العداد.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        SectionTitle("عمليات السيارة")
        if (cars.isEmpty()) EmptyState("مازال ما سجلتي مصاريف السيارة.")
        else cars.forEach { TransactionRow(it, true, { onEdit(it) }, { onDelete(it) }) }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun FuelMetric(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)).padding(12.dp)) {
        Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun ReportsScreen(
    transactions: List<TransactionEntity>,
    budgets: List<BudgetEntity>,
    onSaveBudget: (String, Long) -> Unit,
    onExportJson: () -> Unit,
    onExportCsv: () -> Unit,
    onImport: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var month by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    val monthItems = Finance.month(transactions, month)
    val totals = Finance.totals(monthItems)
    val expenses = monthItems.filter { TxTypes.isExpense(it.type) }
    val groups = expenses.groupBy { if (TxTypes.isCar(it.type)) "مصاريف السيارات" else it.category.ifBlank { "أخرى" } }
        .mapValues { (_, list) -> list.sumOf { it.amountMinor } }
        .toList().sortedByDescending { it.second }
    val budget = budgets.firstOrNull { it.monthKey == month }?.amountMinor ?: 0L
    var budgetInput by remember(month, budget) { mutableStateOf(if (budget > 0L) (budget / 100.0).toString() else "") }
    val ratio = if (budget > 0) totals.expenseMinor.toDouble() / budget else 0.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { month = runCatching { YearMonth.parse(month).minusMonths(1).toString() }.getOrDefault(month) }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
            Text(month, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            IconButton(onClick = { month = runCatching { YearMonth.parse(month).plusMonths(1).toString() }.getOrDefault(month) }) { Text("›", style = MaterialTheme.typography.headlineMedium) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryMini("المداخيل", totals.incomeMinor, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
            SummaryMini("المصاريف", totals.expenseMinor, MaterialTheme.colorScheme.error, Modifier.weight(1f))
            SummaryMini("الصافي", totals.netMinor, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
        }
        SectionTitle("المصاريف حسب التصنيف")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(15.dp)) {
                if (groups.isEmpty()) EmptyState("ما كايناش مصاريف فهاد الشهر.")
                else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        DonutChart(groups.map { it.second })
                        Spacer(Modifier.width(15.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            groups.take(5).forEachIndexed { index, entry ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(9.dp).clip(CircleShape).background(chartColor(index)))
                                    Spacer(Modifier.width(6.dp))
                                    Text(entry.first, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    groups.forEachIndexed { index, entry ->
                        val percent = if (totals.expenseMinor > 0) entry.second.toDouble() / totals.expenseMinor else 0.0
                        Column(Modifier.padding(vertical = 5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(entry.first, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Text(Finance.formatMoney(entry.second), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            }
                            LinearProgressIndicator(
                                progress = { percent.toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = chartColor(index), trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }
            }
        }
        SectionTitle("الميزانية الشهرية")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(15.dp)) {
                OutlinedTextField(
                    value = budgetInput, onValueChange = { budgetInput = it }, label = { Text("الميزانية بالدرهم") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    val parsed = parseNonNegativeMoney(budgetInput)
                    if (parsed == null) launchToast(context, "دخل مبلغ ميزانية صحيح")
                    else onSaveBudget(month, parsed)
                }, modifier = Modifier.fillMaxWidth()) { Text("حفظ ميزانية هاد الشهر") }
                Spacer(Modifier.height(10.dp))
                Text(if (budget > 0) "${Finance.formatMoney(totals.expenseMinor)} من ${Finance.formatMoney(budget)}" else "مازال ما حددتيش الميزانية", style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(
                    progress = { ratio.toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = if (ratio > 1.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                )
                Text(
                    when {
                        budget <= 0 -> "دخل ميزانيتك الشهرية واضغط على حفظ."
                        ratio > 1.0 -> "تجاوزتي الميزانية بـ ${Finance.formatMoney(totals.expenseMinor - budget)}."
                        else -> "استهلكتي ${Finance.formatNumber(ratio * 100)}% وباقي ${Finance.formatMoney(budget - totals.expenseMinor)}."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall
                )
            }
        }
        SectionTitle("النسخ الاحتياطي والتصدير")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(15.dp)) {
                Text("النسخة JSON كتحتافظ بالعمليات والميزانيات، ويمكن استرجاعها حتى من نسخة Mali PWA القديمة.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onExportJson, modifier = Modifier.fillMaxWidth()) { Text("تصدير نسخة احتياطية JSON") }
                OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("استرجاع نسخة JSON") }
                OutlinedButton(onClick = onExportCsv, modifier = Modifier.fillMaxWidth()) { Text("تصدير العمليات CSV") }
                Text("ملفات النسخ الاحتياطية فيها معلومات مالية؛ خزنها فمكان آمن.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun DonutChart(values: List<Long>) {
    val colors = values.indices.map { chartColor(it) }
    val total = values.sum().toFloat().coerceAtLeast(1f)
    Canvas(Modifier.size(132.dp)) {
        var start = -90f
        values.take(8).forEachIndexed { index, value ->
            val sweep = value.toFloat() / total * 360f
            drawArc(
                color = colors[index], startAngle = start, sweepAngle = sweep,
                useCenter = false, style = Stroke(width = 23.dp.toPx(), cap = StrokeCap.Butt)
            )
            start += sweep
        }
    }
}

private fun chartColor(index: Int): Color = listOf(
    Color(0xFF6259DF), Color(0xFF159B72), Color(0xFFE3A23A), Color(0xFFE05A70),
    Color(0xFF3897CA), Color(0xFF9467BD), Color(0xFF8795A8), Color(0xFFBE7A51)
)[index % 8]

@Composable
private fun TransactionEditorDialog(
    initial: TransactionEntity?,
    initialType: String,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var type by remember(initial?.id) { mutableStateOf(initial?.type ?: initialType) }
    var amount by remember(initial?.id) { mutableStateOf(initial?.amountMinor?.let { (it / 100.0).toString() } ?: "") }
    var note by remember(initial?.id) { mutableStateOf(initial?.note ?: "") }
    var category by remember(initial?.id) { mutableStateOf(initial?.category ?: defaultCategory(initialType)) }
    var date by remember(initial?.id) { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var liters by remember(initial?.id) { mutableStateOf(initial?.liters?.toString() ?: "") }
    var odo by remember(initial?.id) { mutableStateOf(initial?.odoKm?.toString() ?: "") }
    var typeMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة عملية" else "تعديل العملية") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 530.dp).verticalScroll(rememberScrollState())) {
                Box {
                    val previousType = type
                    OutlinedButton(onClick = { typeMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("النوع: ${TxTypes.label(type)}") }
                    androidx.compose.material3.DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        TxTypes.all.forEach { option ->
                            androidx.compose.material3.DropdownMenuItem(
                                text = { Text(TxTypes.label(option)) },
                                onClick = { if (category == defaultCategory(previousType)) category = defaultCategory(option); type = option; typeMenu = false }
                            )
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it; error = null }, label = { Text("المبلغ بالدرهم") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(note, { note = it }, label = { Text("الوصف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("التصنيف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(date, { date = it; error = null }, label = { Text("التاريخ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (type == TxTypes.FUEL) {
                    OutlinedTextField(liters, { liters = it; error = null }, label = { Text("اللترات") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(odo, { odo = it; error = null }, label = { Text("عداد السيارة بالكيلومتر") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Text("تسجيل اللترات والعداد ضروري لحساب الاستهلاك بين التعبئات.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amountMinor = Finance.amountToMinor(amount)
                if (amountMinor == null) { error = "دخل مبلغ صحيح أكبر من صفر"; return@TextButton }
                try { LocalDate.parse(date) } catch (_: DateTimeParseException) { error = "التاريخ خاصو يكون بصيغة YYYY-MM-DD"; return@TextButton }
                val litersValue = if (type == TxTypes.FUEL) liters.replace(',', '.').toDoubleOrNull() else null
                val odoValue = if (type == TxTypes.FUEL) odo.toLongOrNull() else null
                if (type == TxTypes.FUEL && (litersValue == null || litersValue <= 0.0 || odoValue == null || odoValue <= 0L)) {
                    error = "دخل اللترات والعداد بأرقام صحيحة أكبر من صفر"; return@TextButton
                }
                onSave(
                    TransactionEntity(
                        id = initial?.id ?: 0L, type = type, amountMinor = amountMinor,
                        note = note.trim().ifBlank { TxTypes.label(type) },
                        category = category.trim().ifBlank { defaultCategory(type) }, date = date,
                        liters = litersValue, odoKm = odoValue,
                        createdAt = initial?.createdAt ?: System.currentTimeMillis()
                    )
                )
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun TransactionRow(
    item: TransactionEntity,
    showActions: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isIncome = item.type == TxTypes.INCOME
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Text(typeIcon(item.type), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(item.note, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(
                "${TxTypes.label(item.type)} · ${item.date}" + if (item.type == TxTypes.FUEL) " · ${item.liters ?: 0.0} لتر · ${item.odoKm ?: 0} كم" else "",
                color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, maxLines = 2
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                (if (isIncome) "+" else "−") + Finance.formatMoney(item.amountMinor),
                color = if (isIncome) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium
            )
            if (showActions) Row {
                TextButton(onClick = onEdit, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("تعديل", style = MaterialTheme.typography.labelSmall) }
                TextButton(onClick = onDelete, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("حذف", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
}

@Composable
private fun SectionTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

private fun typeIcon(type: String): String = when (type) {
    TxTypes.INCOME -> "＋"
    TxTypes.EXPENSE -> "−"
    TxTypes.FUEL -> "⛽"
    TxTypes.MAINTENANCE -> "🔧"
    TxTypes.INSURANCE -> "▣"
    else -> "🚗"
}

private fun defaultCategory(type: String): String = when (type) {
    TxTypes.INCOME -> "مداخيل"
    TxTypes.FUEL, TxTypes.MAINTENANCE, TxTypes.INSURANCE, TxTypes.CAR_OTHER -> "السيارة"
    else -> "مصاريف عامة"
}

private fun parseNonNegativeMoney(raw: String): Long? = try {
    val normalized = raw.trim().replace(',', '.')
    val value = BigDecimal(normalized).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact()
    value.takeIf { it >= 0L }
} catch (_: Exception) { null }

private fun buildCsv(items: List<TransactionEntity>): String = buildString {
    append('\uFEFF')
    append(listOf("التاريخ", "النوع", "الوصف", "التصنيف", "المبلغ بالدرهم", "اللترات", "عداد الكيلومترات").joinToString(";") { csvCell(it) })
    append("\r\n")
    items.forEach { item ->
        val values = listOf(
            item.date, TxTypes.label(item.type), item.note, item.category,
            (item.amountMinor / 100.0).toString(), item.liters?.toString() ?: "", item.odoKm?.toString() ?: ""
        )
        append(values.joinToString(";") { csvCell(it) })
        append("\r\n")
    }
}

private fun csvCell(value: String): String {
    val safe = if (value.trimStart().startsWith("=") || value.trimStart().startsWith("+") || value.trimStart().startsWith("-") || value.trimStart().startsWith("@")) "'$value" else value
    return "\"${safe.replace("\"", "\"\"")}\""
}

private fun launchToast(context: Context, message: String) = launchMain(context) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}

private fun launchMain(context: Context, action: () -> Unit) {
    android.os.Handler(context.mainLooper).post(action)
}
