package ma.mali.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_budgets")
data class BudgetEntity(
    @PrimaryKey val monthKey: String,
    /** Budget in centimes. */
    val amountMinor: Long,
    val updatedAt: Long = System.currentTimeMillis()
)
