package ma.mali.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TransactionEntity::class, BudgetEntity::class],
    version = 1,
    exportSchema = true
)
abstract class MaliDatabase : RoomDatabase() {
    abstract fun maliDao(): MaliDao

    companion object {
        @Volatile private var INSTANCE: MaliDatabase? = null

        fun getInstance(context: Context): MaliDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                MaliDatabase::class.java,
                "mali-local.db"
            ).build().also { INSTANCE = it }
        }
    }
}
