package ma.mali.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class MaliRepository(private val database: MaliDatabase) {
    private val dao = database.maliDao()

    val transactions: Flow<List<TransactionEntity>> = dao.observeTransactions()
    val budgets: Flow<List<BudgetEntity>> = dao.observeBudgets()

    suspend fun saveTransaction(item: TransactionEntity) = dao.upsertTransaction(item)
    suspend fun deleteTransaction(id: Long) = dao.deleteTransaction(id)
    suspend fun saveBudget(item: BudgetEntity) = dao.upsertBudget(item)

    suspend fun replaceAll(items: List<TransactionEntity>, budgets: List<BudgetEntity>) {
        database.withTransaction {
            dao.clearTransactions()
            dao.clearBudgets()
            if (items.isNotEmpty()) dao.insertTransactions(items)
            if (budgets.isNotEmpty()) dao.insertBudgets(budgets)
        }
    }
}
