package ma.mali.app.domain

import ma.mali.app.data.TransactionEntity
import ma.mali.app.data.TxTypes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FinanceTest {
    @Test fun balanceSeparatesIncomeFromAllExpenseTypes() {
        val items = listOf(
            tx(TxTypes.INCOME, 250_000),
            tx(TxTypes.EXPENSE, 40_000),
            tx(TxTypes.FUEL, 20_000)
        )
        val totals = Finance.totals(items)
        assertEquals(250_000L, totals.incomeMinor)
        assertEquals(60_000L, totals.expenseMinor)
        assertEquals(190_000L, totals.balanceMinor)
    }

    @Test fun fuelEfficiencyUsesRefillsAfterTheFirstFullTank() {
        val items = listOf(
            fuel(20_000, 50.0, 10_000),
            fuel(24_000, 48.0, 10_600),
            fuel(25_000, 50.0, 11_200)
        )
        val stats = Finance.fuelStats(items)
        assertEquals(1_200L, stats.distanceKm)
        assertEquals(98.0, stats.usedLiters, 0.0001)
        assertEquals(8.166666, stats.litersPer100Km!!, 0.0001)
        assertEquals(0.408333, stats.costPerKm!!, 0.0001)
    }

    @Test fun malformedOrNonPositiveAmountIsRejected() {
        assertNull(Finance.amountToMinor("abc"))
        assertNull(Finance.amountToMinor("0"))
        assertEquals(12345L, Finance.amountToMinor("123,45"))
        assertEquals(12346L, Finance.amountToMinor("123.455"))
    }

    private fun tx(type: String, amount: Long) = TransactionEntity(
        type = type, amountMinor = amount, note = "test", category = "test", date = "2026-11-01"
    )

    private fun fuel(amount: Long, liters: Double, odo: Long) = TransactionEntity(
        type = TxTypes.FUEL, amountMinor = amount, note = "fuel", category = "سيارة",
        date = "2026-11-01", liters = liters, odoKm = odo
    )
}
