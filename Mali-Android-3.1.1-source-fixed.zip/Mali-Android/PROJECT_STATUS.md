# Project status — Mali 3.0

Implemented in source:
- Android Native app structure (Kotlin + Compose)
- Room local database for transactions and monthly budgets
- Income/expense/car transaction types
- Create, edit, delete, search, month filtering
- Light/dark theme preference
- Monthly reports, category donut chart, per-month budgets
- Fuel consumption calculation
- JSON backup and restore; supports prior PWA v2 structure
- CSV export
- No INTERNET permission; Android Auto Backup disabled
- Unit tests for finance calculations
- GitHub Actions workflow for tests + debug APK

Not verified in this environment:
- Android compilation, because Android SDK and Gradle are not installed here
- Runtime behavior on a physical device
- APK signing for Play Store/release distribution

The GitHub Actions workflow is configured to perform the build and unit tests after the project is pushed to GitHub.


Version 3.1.0 changes:
- Optional biometric gate at app launch (requires an enrolled biometric on the device).
- Moroccan dirham currency formatting retained.
- Cloud sign-in and cloud backup remain intentionally out of scope until a backend/provider and its credentials are supplied.
